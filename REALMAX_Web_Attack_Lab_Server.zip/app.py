from flask import Flask, request, jsonify, send_from_directory
from datetime import datetime, timezone
import os
from pathlib import Path

app = Flask(__name__, static_folder="static")
APP_NAME = "REALMAX Web Attack Lab"
MAX_TEXT = 2000

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; img-src 'self' data:"
    return response

@app.get("/")
def home():
    return send_from_directory("static", "index.html")

@app.get("/api/health")
def health():
    return jsonify({"app": APP_NAME, "status": "online", "mode": "safe-simulation",
                    "time": datetime.now(timezone.utc).isoformat()})

@app.post("/api/lab/echo")
def safe_echo():
    data = request.get_json(silent=True) or {}
    text = str(data.get("text", ""))[:MAX_TEXT]
    # Returns text as JSON; frontend renders it with textContent, never as HTML.
    return jsonify({"mode": "safe-text-only", "length": len(text), "text": text,
                    "note": "Input was not executed as HTML or JavaScript."})

@app.post("/api/lab/login-policy")
def login_policy():
    data = request.get_json(silent=True) or {}
    try:
        length = max(0, min(100, int(data.get("password_length", 0))))
    except (TypeError, ValueError):
        length = 0
    rate_limit = bool(data.get("rate_limit", False))
    mfa = bool(data.get("mfa", False))
    findings = []
    if length < 12:
        findings.append("Use a longer password or passphrase (12+ characters is a useful baseline).")
    if not rate_limit:
        findings.append("Add rate limiting or progressive delays to login attempts.")
    if not mfa:
        findings.append("Enable multi-factor authentication where possible.")
    return jsonify({"mode": "policy-simulation", "status": "review" if findings else "baseline-ok",
                    "findings": findings, "note": "No real accounts or passwords are checked."})

@app.post("/api/lab/audit")
def audit():
    # Intentionally fixed, simulated findings; does not accept target URLs or scan hosts.
    return jsonify({
        "mode": "simulated-audit",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "findings": [
            {"severity": "REVIEW", "title": "Output encoding", "detail": "Render untrusted content as text and encode output for its context."},
            {"severity": "REVIEW", "title": "Database access", "detail": "Use parameterized queries / prepared statements."},
            {"severity": "CHECK", "title": "Security headers", "detail": "Review CSP, X-Content-Type-Options, frame protections and Referrer-Policy."},
            {"severity": "CHECK", "title": "Authentication", "detail": "Use MFA, rate limiting and secure session-cookie settings."}
        ],
        "note": "This is a training report, not a scan of a real target."
    })

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    # Local development default. For a public deployment, use a production WSGI server.
    app.run(host="0.0.0.0", port=port, debug=False)
