REALMAX Web Attack Lab — Server Edition
========================================

Includes:
- Flask backend API
- Responsive cyber-themed frontend
- Safe XSS output demo (text-only; input is never executed)
- Login policy simulation
- Fixed simulated audit report
- Basic security response headers
- Render deployment configuration

Local run:
1. Install Python 3.10+.
2. In this folder, run: pip install -r requirements.txt
3. Run: python app.py
4. Open http://127.0.0.1:5000

Deploy on Render:
1. Create a GitHub repository and upload all files/folders.
2. In Render, create a new Web Service and connect that repository.
3. Build command: pip install -r requirements.txt
4. Start command: gunicorn app:app
5. Deploy and open the generated HTTPS URL.

Safety scope:
- The app does not accept target URLs.
- No real vulnerability scanning, exploitation, brute force, or network probing is implemented.
- All labs are simulations for learning defensive concepts.
- Before public deployment, consider adding authentication, request limits, logging controls,
  and a database only if persistence is needed. Do not put secrets in source control.
